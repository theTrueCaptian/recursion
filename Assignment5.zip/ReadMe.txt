Here is how to run:
java -jar "F:\recursionNetbeans\dist\recursionNetbeans.jar"

******************************************************************************
Note: Please replace F with your directory to where this jar file is copied.
**************************************************************************